const mongoose = require("mongoose");

// Define the schema for a Song
const songSchema = new mongoose.Schema({
  title: { type: String, required: true },
  name: { type: String, required: true },
  status: { type: String, default: "Not Started" },
});

// Export the Song model
module.exports = mongoose.model("Song", songSchema);
