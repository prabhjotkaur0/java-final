const mongoose = require("mongoose");

// Define the schema for a Singer
const schemaObj = {
    name: { type: String, required: true },
    dob: { type: String, required: true }
};

// Create the Mongoose schema
const mongooseSchema = mongoose.Schema(schemaObj);

// Export the Singer model
module.exports = mongoose.model("Singer", mongooseSchema);
