const express = require("express");
const router = express.Router();
const Singer = require("../models/singer");  // Changed from Author to Singer
const AuthenticationMiddleware = require("../extensions/authentication");

// GET /singers/
router.get("/", AuthenticationMiddleware, async (req, res, next) => {
  let singers = await Singer.find().sort([["name", "ascending"]]);  // Sorting by name of the singer
  res.render("singers/index", { title: "Singer List", dataset: singers, user: req.user });
});

// GET /singers/Add
router.get("/add", AuthenticationMiddleware, (req, res, next) => {
  res.render("singers/add", { title: "Add a new Singer", user: req.user });
});

// POST /singers/Add
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  let newSinger = new Singer({
    name: req.body.name,
    dob: req.body.dob,
    genre: req.body.genre, // Added genre for singer
  });
  await newSinger.save();
  res.redirect("/singers");
});

module.exports = router;
