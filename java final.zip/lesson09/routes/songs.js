// Naming convention > controllers/routers are plural
// Import express and create router object
const express = require("express");
const router = express.Router();

// Import mongoose model to be used
const Song = require("../models/song");
const Singer = require("../models/singer");

// Middleware for authentication
const AuthenticationMiddleware = require("../extensions/authentication");

// Configure GET/POST handlers
// Path relative to the one configured in app.js > /songs

// GET /songs/
router.get("/", async (req, res, next) => {
  try {
    // Retrieve ALL data and sort by title in descending order
    let songs = await Song.find().sort([["title", "descending"]]);
    // Render view
    res.render("songs/index", {
      title: "Songs Tracker",
      dataset: songs,
      user: req.user,
    });
  } catch (error) {
    next(error); // Proper error handling
  }
});

// GET /songs/add
router.get("/add", AuthenticationMiddleware, async (req, res, next) => {
  try {
    let singerList = await Singer.find().sort([["name", "ascending"]]);
    res.render("songs/add", {
      title: "Add a New Song",
      singers: singerList, // Use 'singers' for clarity
      user: req.user,
    });
  } catch (error) {
    next(error);
  }
});

// POST /songs/add
router.post("/add", AuthenticationMiddleware, async (req, res, next) => {
  try {
    // Use the Song model to save data to DB
    let newSong = new Song({
      title: req.body.title,
      name: req.body.name,
      status: req.body.status , // Fallback for status
    });
    await newSong.save();
    res.redirect("/songs");
  } catch (error) {
    next(error);
  }
});

// GET /songs/delete/_id
router.get("/delete/:_id", AuthenticationMiddleware, async (req, res, next) => {
  try {
    let songId = req.params._id;
    await Song.findByIdAndRemove(songId); // Simplified syntax
    res.redirect("/songs");
  } catch (error) {
    next(error);
  }
});

// GET /songs/edit/_id
router.get("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  try {
    let songId = req.params._id;
    let songData = await Song.findById(songId);
    if (!songData) {
      res.status(404).send("Song not found"); // Handle invalid IDs
      return;
    }
    let singerList = await Singer.find().sort([["name", "ascending"]]);
    res.render("songs/edit", {
      title: "Edit Song Info",
      song: songData,
      singers: singerList, // Ensure consistency with key names
      user: req.user,
    });
  } catch (error) {
    next(error);
  }
});

// POST /songs/edit/_id
router.post("/edit/:_id", AuthenticationMiddleware, async (req, res, next) => {
  try {
    let songId = req.params._id;
    let updatedSong = await Song.findByIdAndUpdate(
      songId, // filter to find the song to update
      {
        title: req.body.title,
        name: req.body.name,
        status: req.body.status,
      },
      { new: true } // Return updated document
    );
    if (!updatedSong) {
      res.status(404).send("Song not found"); // Handle invalid IDs
      return;
    }
    res.redirect("/songs");
  } catch (error) {
    next(error);
  }
});

// Export router object
module.exports = router;
