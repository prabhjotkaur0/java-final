const express = require("express");
const router = express.Router();
const User = require("../models/user");
const passport = require("passport");

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express", user: req.user });
});

// GET /login
router.get("/login", (req, res, next) => {
  // Obtain session messages if any
  let messages = req.session.messages || [];
  // Clear messages
  req.session.messages = [];
  // Pass messages to view
  res.render("login", { title: "Login", messages: messages, user: req.user });
});

// POST /login
router.post(
  "/login",
  passport.authenticate("local", {
    successRedirect: "/songs", // Redirect to songs after successful login
    failureRedirect: "/login",
    failureMessage: "Invalid credentials",
  })
);

// GET /register
router.get("/register", (req, res, next) => {
  res.render("register", { title: "Create a new account", user: req.user });
});

// POST /register
router.post("/register", (req, res, next) => {
  // Create a new user based on the information from the page
  User.register(
    new User({
      username: req.body.username,
    }),
    req.body.password,
    (err, newUser) => {
      if (err) {
        console.log(err);
        // Reload register page on error
        return res.redirect("/register");
      } else {
        // Log user in and redirect
        req.login(newUser, (err) => {
          res.redirect("/songs"); // Redirect to songs after registration
        });
      }
    }
  );
});

// GET /logout
router.get("/logout", (req, res, next) => {
  req.logout((err) => {
    res.redirect("/login");
  });
});

// GET /google
// Triggers when user clicks on the "Login with Google" button on the login page
router.get(
  "/google",
  passport.authenticate("google", { scope: ["email", "profile"] })
);

// GET /google/callback
// Callback URL where Google redirects after authentication
router.get(
  "/google/callback",
  passport.authenticate("google", { failureRedirect: "/login" }),
  (req, res, next) => {
    res.redirect("/songs"); // Redirect to songs after successful Google login
  }
);

module.exports = router;